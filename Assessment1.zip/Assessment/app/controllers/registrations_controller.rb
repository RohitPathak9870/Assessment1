class RegistrationsController < ApplicationController
  def create
    @user = User.create(user_params)

    if @user.save
      redirect_to new_user_session_path
   else
       
      render 'registrations_create_path'
   end

  end

  private

  def user_params
    user.require(:user).permit(:email, :role, :password, :account_no, :fullname)

  end
end
