class PropertiesController < ApplicationController
  

   def index
    @properties = Property.all
  end

  def show
    @property=Property.find(params[:id])
  end

  def new
     @property = Property.new
  end

  def edit
    @property=Property.find(params[:id])
  end

  def create
    @property = Property.new(property_params)
    @property.user_id=current_user.id
    respond_to do |format|
      if @property.save
        format.html { redirect_to property_path(@property), notice: "Property was successfully created." }
      else
        format.html { render :new, status: :unprocessable_entity }
      end 
    end    
  end 

  def update
    @property=Property.find(params[:id])
    
      if @property.update(property_params)
        redirect_to property_path
      else
        render :edit, status: :unprocessable_entity 
      end
    
  end

  def destroy
    @property=Property.find(params[:id])
    @property.destroy
      respond_to do |format|
        format.html { redirect_to properties_path notice: "Property was successfully destroyed." }
      end
  end
  private
  
  

  def property_params
    params.require(:property).permit(:name, :address, :latitude, :longitude)
  end
end