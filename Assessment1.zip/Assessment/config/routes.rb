Rails.application.routes.draw do
  
  
  devise_for :users 
  root "homes#home"
  resources :bookings

  resources :properties


  # get 'bookings/new'
  # get 'bookings/show'
  #get 'customer_dashboards/index'
  
  #get 'registrations/create'

   
  
  
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Defines the root path route ("/")
  # root "articles#index"
end
