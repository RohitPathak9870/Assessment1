require "test_helper"

class PropertyDashboardsControllerTest < ActionDispatch::IntegrationTest
  test "should get index" do
    get property_dashboards_index_url
    assert_response :success
  end
end
